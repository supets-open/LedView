/**
Coded by: Liulijun@dlnu.edu.cn
2013.10.29
*/
import java.io.*;

public class TestAscii {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str = "I Love Java!";
		int n = str.length();

		char ch[] = new char[n];

		for (int i = 0; i < n; i++) {
			ch[i] = str.charAt(i);

		}

		byte[][] asc = new byte[n][16];

		try {
			FileOutputStream outfile = new FileOutputStream("out.txt");
			OutputStreamWriter out=new OutputStreamWriter(outfile);

			for (int i = 0; i < n; i++) {

				FileInputStream file = new FileInputStream("ASC16");
				

				int off = ch[i] * 16;

				file.skip(off);
				file.read(asc[i]);

				file.close();

			}

			for (int i = 0; i < 16; i++) {

				for (int id = 0; id < n; id++) {

					for (int j = 0; j < 8; j++) {

						int bit = (asc[id][i] & (0x80 >> j)) >> (7 - j);
						/* ��λ���룬Ϊ1�ߴ�ӡ��*���������ӡ�ո� */
						if (bit == 1){
							System.out.print("*");
							out.write("*");
						}
						else{
							System.out.print(" ");
							out.write(" ");
						}
					}
				}

				System.out.println();
				out.write("\r\n");
			}

	       out.close();


		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}
}
