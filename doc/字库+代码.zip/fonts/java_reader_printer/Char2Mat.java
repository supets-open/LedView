import java.io.IOException;


public class Char2Mat {
	private int font_size = 48;
	private int font_height = font_size;
	private int font_width = font_size;
	private int size_step = 8;
	private char word = '我';
	private byte[] cbuf;
	private char[] key = {0x80, 0x40, 0x20, 0x10, 0x08, 0x04, 0x02, 0x01};
	
	public Char2Mat(int font_size, char word) {
		this.font_size = font_size;
		this.font_height = font_size;
		if (font_size == 12 || font_size == 14) {
			this.font_width = 16;
		} else {
			this.font_width = font_size;
		}
		this.word = word;
	}
	
	public void getMat() {
		try {
			int sizeof_byte = size_step;
			int offset_step = font_width * font_height / sizeof_byte;

			byte[] incode = String.valueOf(word).getBytes("GB2312");
			int t1 = (incode[0] & 0xff);
			int t2 = (incode[1] & 0xff);
			int offset = 0;

			// calculate offset for different size font
			if (t1 > 0xa0) {
				if (font_size == 40 || font_size == 48) {
					offset = ((t1 - 0xa1 - 0x0f) * 94 + (t2 - 0xa1)) * offset_step;
				} else if (font_size == 12 || font_size == 14 || font_size == 16 || font_size == 24 || font_size == 32) {
					offset = ((t1 - 0xa1) * 94 + (t2 - 0xa1)) * offset_step;
				}
			} else {
				offset = (t1 + 156 - 1) * offset_step;
			}

			String fileName = "HZK/" + String.valueOf(font_size) + "/HZK" + String.valueOf(font_size);
			System.out.println(fileName);
			cbuf = Utils.getFileBytes(fileName, offset, offset_step);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void print() {
		if (font_size == 12 || font_size == 14 || font_size == 40 || font_size == 48) {
//			Utils.printMatHorizontal(cbuf, key, font_width, font_height, size_step);
			for (int i = 0; i < font_size; i++) {
				for (int j = 0; j < font_size; j++) {
					int index = i * font_width + j;
					int flag = cbuf[index / size_step] & key[index % size_step];
					System.out.print(flag > 0 ? "+" : "o");
				}
				System.out.println();
			}
		} else if (font_size == 16 || font_size == 24 || font_size == 32) {
//			Utils.printMatVertical(cbuf, key, font_width, font_height, size_step);
			for (int i = 0; i < font_size; i++) {
				for (int j = 0; j < font_size; j++) {
					int index = j * font_width + i;
					int flag = cbuf[index / size_step] & key[index % size_step];
					System.out.print(flag > 0 ? "+" : "o");
				}
				System.out.println();
			}
		}
	}
}
