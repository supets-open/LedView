import java.io.*;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;
import java.util.StringJoiner;

/**
 * Created by zzl on 17/1/11.
 */
public final class Utils {

    public static byte[] getFileBytes(String path, int offset, int offset_step) {
        try {

            File temp = new File(getContextClassLoader().getResource(path).toURI());
            FileInputStream inputStream = new FileInputStream(temp);
            inputStream.skip(offset);
            byte[] cbuf = new byte[offset_step];
            if (inputStream.read(cbuf, 0, offset_step) < 0) {
                System.out.println("read failed!");
                inputStream.close();
                return null;
            }

            inputStream.close();
            return cbuf;

        } catch (IOException | URISyntaxException e) {
            e.printStackTrace();
            return null;
        }
    }

    private static ClassLoader getContextClassLoader() {
        return Thread.currentThread().getContextClassLoader();
    }
}
