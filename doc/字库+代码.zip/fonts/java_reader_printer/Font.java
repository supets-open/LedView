public class Font {
    public static void main(String[] args) {
        Num2Mat nm = new Num2Mat(48, 24, 'A');
        nm.getMat();
        nm.print();

		System.out.println("\n==========================\n");

        Char2Mat cm = new Char2Mat(48, '二');
        cm.getMat();
        cm.print();
    }
}